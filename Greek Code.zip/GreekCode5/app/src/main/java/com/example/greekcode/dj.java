package com.example.greekcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class dj extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dj);

        Button btn;
        btn=findViewById(R.id.enroll);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencourse();
            }
        });



        Button BTN;
        BTN = findViewById(R.id.button2);
        BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openjbl();
            }
        });



        Button BTN2;
        BTN2 = findViewById(R.id.button3);
        BTN2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(dj.this, "Watch Complete Video First!!!!!!", Toast.LENGTH_SHORT).show();
            }
        });








        ImageView img;
        img = findViewById(R.id.circullum);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openUrl();

            }
        });



    }

    private void openjbl() {
        String url ="https://docs.google.com/document/d/1PoL4bPBRaz1LVwruiFlTTx48HgBPMkT0vCMqcufBYN0/edit?usp=sharing";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    private void opencourse() {
        String url2= "https://drive.google.com/file/d/1bXUVMEJQ383sc_bHKbuBKpN8SdLGo0Yc/view?usp=drive_link, https://drive.google.com/file/d/1KrUd6X0Fem9MPbuH3h_QOOsJenefsWY6/view?usp=drive_link";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url2));
        startActivity(intent);
    }


    private void openUrl() {
        String url1 = "https://docs.google.com/document/d/1QIDKRrjaAigKHfvJm4RfLfuOvGN99CTbU97Z52dWntI/edit?usp=sharing"; // Replace with your desired URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url1));
        startActivity(intent);



    }
}