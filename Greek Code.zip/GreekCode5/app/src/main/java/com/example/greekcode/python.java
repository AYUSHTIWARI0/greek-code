package com.example.greekcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class python extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_python);
        Button btn;
        btn=findViewById(R.id.enroll);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencourse();
            }
        });



        Button BTN2;
        BTN2 = findViewById(R.id.button3);
        BTN2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(python.this, "Watch Complete Video First!!!!!!", Toast.LENGTH_SHORT).show();
            }
        });





        ImageView img;
        img = findViewById(R.id.circullum);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openUrl();

            }
        });





        Button BTN;
        BTN = findViewById(R.id.button2);
        BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openjbl();
            }
        });

    }

    private void openjbl() {

        String url ="https://drive.google.com/file/d/1L2TRXt9Cmdm4wnLK-cgAp8oIW--iljNS/view?usp=drive_link";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }


    private void openUrl() {
        String url1 = "https://drive.google.com/file/d/1QAunx8iBuGVcwtf-ssWT5v-Mz5B8jhGz/view?usp=drive_link"; // Replace with your desired URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url1));
        startActivity(intent);
    }

    private void opencourse() {
        String  url3="https://drive.google.com/drive/folders/1unRK0E2Sxlc86YdDk3DU6l792ZXRvGCs?usp=sharing";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url3));
        startActivity(intent);
    }
    }
