package com.example.greekcode;

public class MobileAds {
    public static void initialize(dashboard dashboard, OnInitializationCompleteListener onInitializationCompleteListener) {
    }
}
