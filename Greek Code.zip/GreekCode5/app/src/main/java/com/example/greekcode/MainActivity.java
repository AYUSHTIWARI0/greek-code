package com.example.greekcode;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.ktx.Firebase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView anim;
    AutoCompleteTextView view;
    TextView txt;
    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button;
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText edttxtusername;
                edttxtusername = findViewById(R.id.editTextTextEmailAddress);
                String username = edttxtusername.getText().toString();

                EditText editTextpass;
                editTextpass = findViewById(R.id.editTextTextPassword);
                String password = editTextpass.getText().toString();

                if (username.isEmpty() || password.isEmpty()){
                    Toast.makeText(MainActivity.this, "Username and password are required.", Toast.LENGTH_SHORT).show();
                } else if (username.equals("admin") && password.equals("admin")) {
                    Intent Dash = new Intent(MainActivity.this, dashboard.class);
                    startActivity(Dash);
                    finish();
                }else{
                    auth.createUserWithEmailAndPassword(username,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                           if ((task.isSuccessful())){
                               Toast.makeText(MainActivity.this,"stored in fire",Toast.LENGTH_SHORT).show();
                               startActivity(new Intent(MainActivity.this,dashboard.class));
                           }else{
                               Toast.makeText(MainActivity.this,"login failed",Toast.LENGTH_SHORT).show();
                           }
                        }
                    });
                }
            }
        });

        Button myButton = findViewById(R.id.button);
        myButton.setBackgroundColor(getResources().getColor(R.color.blue));




        ArrayList <String> arrayList =  new ArrayList<>();





        TextView txt;
        txt = findViewById(R.id.txtforget);
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,signup.class);
                startActivity(intent);
            }
        });

        auth = FirebaseAuth.getInstance();


        txt.findViewById(R.id.newacc);
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,signup.class);
                startActivity(intent);
            }
        });

















    }
}
