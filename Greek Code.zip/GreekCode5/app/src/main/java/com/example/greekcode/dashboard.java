
package com.example.greekcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


import com.google.firebase.auth.FirebaseAuth;

public class dashboard extends AppCompatActivity {

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        auth = FirebaseAuth.getInstance();
        Button btn;
        btn=findViewById(R.id.enrollButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencourse();
            }
        });




        Button btn1;
        btn1=findViewById(R.id.enrollButton1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {openpy();
            }
        });




       Button img;
        img = findViewById(R.id.exploreButton);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dash1 = new Intent(dashboard.this, java.class);
                startActivity(Dash1);
            }

        });





        ImageView imgcw;
        imgcw = findViewById(R.id.pythonview3);
        imgcw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(dashboard.this,content.class);
                startActivity(intent);
            }
        });




        Button imgpy;
        imgpy = findViewById(R.id.exploreButton1);
        imgpy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dash2 = new Intent(dashboard.this,python.class);
                startActivity(Dash2);
            }
        });

        Button imgcontent = findViewById(R.id.exploreButton3);
        imgcontent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dash3 = new Intent(dashboard.this, content.class);
                startActivity(Dash3);

            }
        });







        Button imgstock;
        imgstock = findViewById(R.id.exploreButton2);
        imgstock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Dash3 = new Intent(dashboard.this, dj.class);
                startActivity(Dash3);
            }
        });

        Button imgcontent1 = findViewById(R.id.enrollButton3);
        imgcontent1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opencontent();
            }
        });




        Button button;
        button=findViewById(R.id.enrollButton2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openstock();
            }
        });


    }

    private void opencontent() {
        String url2= "https://drive.google.com/drive/folders/1F7owAsZgaWoHeOQAr_z88zhWGztZFcYt?usp=drive_link";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url2));
        startActivity(intent);
    }

    private void openstock() {
        String url2= "https://drive.google.com/file/d/1bXUVMEJQ383sc_bHKbuBKpN8SdLGo0Yc/view?usp=drive_link, https://drive.google.com/file/d/1KrUd6X0Fem9MPbuH3h_QOOsJenefsWY6/view?usp=drive_link";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url2));
        startActivity(intent);
    }

    private void openpy() {String  url3="https://drive.google.com/drive/folders/1unRK0E2Sxlc86YdDk3DU6l792ZXRvGCs?usp=sharing";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url3));
        startActivity(intent);

    }

    private void opencourse() {
        String  url3="https://drive.google.com/drive/folders/1XIgLR62OsoGILykYdqxWkWGw5jq1n4dg?usp=sharing";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url3));
        startActivity(intent);
    }
}


