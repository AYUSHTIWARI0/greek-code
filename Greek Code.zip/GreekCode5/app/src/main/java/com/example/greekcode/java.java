package com.example.greekcode;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;

public class java extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java);
        Button BTN;
        BTN = findViewById(R.id.button2);
        BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openjbl();
            }
        });

        



        Button BTN2;
        BTN2 = findViewById(R.id.button3);
        BTN2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(java.this, "Watch Complete Video First!!!!!!", Toast.LENGTH_SHORT).show();
            }
        });



        ImageView img;
        img = findViewById(R.id.circullum);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openUrl();

            }
        });

        ImageView core;
        core = findViewById(R.id.core);
        core.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opencore();

            }
        });


        Button btn;
        btn=findViewById(R.id.enroll);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencourse();
            }
        });




    }

    private void opencourse() {
        String  url3="https://drive.google.com/drive/folders/1XIgLR62OsoGILykYdqxWkWGw5jq1n4dg?usp=sharing";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url3));
        startActivity(intent);
    }

    private void opencore() {
        String url2= "https://drive.google.com/file/d/1qii1qzALFlpZwm3vNHRISE-3H9CT83tB/view?usp=drive_link";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url2));
        startActivity(intent);
    }


    private void openjbl() {
        String url ="https://drive.google.com/file/d/1Tnn6UYXWShCQXr6iTyzbls_7KGCWLKun/view?usp=sharing";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }





    private void openUrl() {
        String url1 = "https://drive.google.com/file/d/1VhUKEqw1sox8QdP0YrWqzCL_3UDgN_Ir/view?usp=sharing"; // Replace with your desired URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url1));
        startActivity(intent);
    }



}
