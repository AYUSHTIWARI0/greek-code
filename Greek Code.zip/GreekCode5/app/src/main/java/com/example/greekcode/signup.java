package com.example.greekcode;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signup extends AppCompatActivity {




    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        TextView help;
        help = findViewById(R.id.help);
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(signup.this,Help.class);
                startActivity(intent1);
            }
        });






        EditText editText = findViewById(R.id.editTextTextEmailAddress2);
        Button button = findViewById(R.id.btnGLS);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = editText.getText().toString();  // Get email value on button click

                if (email.isEmpty()) {
                    Toast.makeText(signup.this, "Fill Mail ID", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(signup.this, forgetmail.class);
                    startActivity(intent);
                }
            }
        });



    }
}