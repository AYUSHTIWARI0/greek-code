package com.example.greekcode;

public class InitializationStatus {
}
