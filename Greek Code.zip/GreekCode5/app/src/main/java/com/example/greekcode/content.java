package com.example.greekcode;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class content extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);
        ImageView img;
        img = findViewById(R.id.circullum);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openUrl();

            }
        });

        Button btn1;
        btn1=findViewById(R.id.enroll1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencourse1();
            }
        });




    }

    private void opencourse1() {String  url3="https://drive.google.com/drive/folders/1F7owAsZgaWoHeOQAr_z88zhWGztZFcYt?usp=drive_link";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url3));
        startActivity(intent);
    }


    private void openUrl() {
        String url1 = "https://drive.google.com/drive/folders/1F7owAsZgaWoHeOQAr_z88zhWGztZFcYt?usp=sharing"; // Replace with your desired URL
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url1));
        startActivity(intent);
    }
}