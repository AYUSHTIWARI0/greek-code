package com.example.greekcode;

public abstract class OnInitializationCompleteListener {
    public abstract void onInitializationComplete(InitializationStatus initializationStatus);
}
